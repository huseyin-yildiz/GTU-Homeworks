package com.automation;

public class Admin extends Employee{
	public Admin(String name, String phone, String email, String password) {
		super(name, phone, email, password);
	}
}
