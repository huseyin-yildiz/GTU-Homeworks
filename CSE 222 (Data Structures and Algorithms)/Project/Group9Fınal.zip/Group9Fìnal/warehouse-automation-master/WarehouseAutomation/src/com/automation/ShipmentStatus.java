package com.automation;

public enum ShipmentStatus {
    NONE,
    PACKED,
    SHIPPED,
    DELIVERED
}
