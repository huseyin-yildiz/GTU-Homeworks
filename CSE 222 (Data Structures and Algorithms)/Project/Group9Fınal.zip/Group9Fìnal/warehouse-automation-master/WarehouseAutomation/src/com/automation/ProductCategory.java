package com.automation;

public enum ProductCategory {
    drinks,
    snack,
    fruit,
    vegetable,
    bread,
    water;
}
