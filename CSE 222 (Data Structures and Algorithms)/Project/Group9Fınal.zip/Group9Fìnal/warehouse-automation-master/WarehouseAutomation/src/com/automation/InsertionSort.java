package com.automation;
import java.util.List;

/** Implements the insertion sort algorithm.
 *  @author Koffman and Wolfgang
 * */

public class InsertionSort {
    /** Sort the table using insertion sort algorithm.
     pre:  table contains Comparable objects.
     post: table is sorted.
     @param table The array to be sorted
     */
    public static < T
            extends Comparable < T >> void sort(List<T> table) {
        for (int nextPos = 1; nextPos < table.size(); nextPos++) {
            // Invariant: table[0 . . . nextPos - 1] is sorted.
            // Insert element at position nextPos
            // in the sorted subarray.
            insert(table, nextPos);
        } // End for.
    } // End sort.

    /** Insert the element at nextPos where it belongs
     in the array.
     pre:  table[0 . . . nextPos - 1] is sorted.
     post: table[0 . . . nextPos] is sorted.
     @param table The array being sorted
     @param nextPos The position of the element to insert
     */
    private static < T
            extends Comparable < T >> void insert(List<T> table,
                                                  int nextPos) {
        T nextVal = table.get(nextPos); // Element to insert.
        while (nextPos > 0
                && nextVal.compareTo(table.get(nextPos-1)) < 0) {
            table.set(nextPos,table.get(nextPos-1));// Shift down.
            nextPos--; // Check next smaller element.
        }
        // Insert nextVal at nextPos.
        table.add(nextPos,nextVal);
    }
}
