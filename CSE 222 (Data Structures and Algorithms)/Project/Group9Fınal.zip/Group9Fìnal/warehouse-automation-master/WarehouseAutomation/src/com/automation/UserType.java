package com.automation;

public enum UserType {
    ADMIN,
    TRANSPORTATION_EMPLOYEE,
    BRANCH_EMPLOYEE,
    WAREHOUSE_EMPLOYEE
}
