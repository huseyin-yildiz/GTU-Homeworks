package com.automation;

public enum EmployeeStatus {
    WAITING_FOR_APPROVAL,
    APPROVED,
    REJECTED
}